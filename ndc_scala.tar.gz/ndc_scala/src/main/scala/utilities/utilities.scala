package com.optus.ndc.utilities;

object StringUtils {
  implicit class StringImprovements(val s: String) {
    import scala.util.control.Exception._
    def strToLongOpt = catching(classOf[NumberFormatException]) opt s.toLong
  }
}

object AnyUtils {
  implicit class AnyImprovements(val a: Any) {
    import scala.util.control.Exception._
    def anyToLongOpt = catching(classOf[ClassCastException],classOf[NullPointerException]) opt a.asInstanceOf[Long]
  }
}
