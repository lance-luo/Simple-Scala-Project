package com.optus.ndc.location;

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import com.optus.ndc.utilities.StringUtils._
import com.optus.ndc.utilities.AnyUtils._
import java.text.SimpleDateFormat
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext

object ExpandedLocTS {
    
  //Subscriber location structure
  //case class Subloc(imsi: String, loctime: Long, values: String, sampletime: Long);
  case class LocEvent(imsi: String,loctimestamp: Long,key: String,rattype: Int,nxttime: Option[Long],nxtkey: String,prevtime: Option[Long],prevkey: String);
  //case class LocEventTS(loc_event : LocEvent,sampletime: Long);
  case class LocExpandedTS(imsi: String,loctimestamp: Long,key: String,rattype: Int,nxttime: Option[Long],nxtkey: String,prevtime: Option[Long],prevkey: String,sampletime: Long);

  def main(args: Array[String]) {
    if (args.length < 5) {
      System.err.println("Usage: locationdata <hdfs input path> <hdfs output path> "+
        "<sample interval (s)> <local start time yyyyMMddHHmm> <local end time yyyyMMddHHmm>")
      System.exit(1)
    }

    val sc = new SparkContext()
    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
    import sqlContext.implicits._
    val hdfs = org.apache.hadoop.fs.FileSystem.get(sc.hadoopConfiguration);
    
    //Properties
    //val blockSize = 1024 * 1024 * 256;      // 256MB
    //val splitSize = 1024 * 1024 * 256;        //256MB
    //sc.hadoopConfiguration.setInt( "dfs.blocksize", blockSize );
    //sc.hadoopConfiguration.setInt( "parquet.block.size", blockSize );
    //sc.hadoopConfiguration.setInt( "mapreduce.input.fileinputformat.split.minsize", splitSize );
    //sc.hadoopConfiguration.setInt( "mapreduce.input.fileinputformat.split.maxsize", splitSize );
    sqlContext.setConf("spark.sql.parquet.compression.codec","snappy");
    
    //Runtime Arguments
    val locevents_path = args(0)
    val locexpandedts_path = args(1)
    val timesample = args(2).toInt
    val df = new SimpleDateFormat("yyyyMMddHHmm");
    val starttime = df.parse(args(3)).getTime(); 
    val endtime = df.parse(args(4)).getTime(); 
     
    //Constants
    val timesample_ms = (timesample*1000).toLong;

    //Job Prep
    //Remove output path if exists
    val hdfs_outputpath = new org.apache.hadoop.fs.Path(locexpandedts_path);
    if (hdfs.exists(hdfs_outputpath)) {
      hdfs.delete(hdfs_outputpath, true);
    }
    
    //Transforms
    //val locevents = sc.textFile(locevents_path)
    val locevents_input = sqlContext.read.parquet(locevents_path);
    val locts = locevents_input
      .map(
        row => (
          LocEvent(
            row.getString(0),
            row.getLong(1),
            row.getString(2),
            row.getInt(3),
            row.get(4).anyToLongOpt,
            row.getString(5),
            row.get(6).anyToLongOpt,
            row.getString(7)
          ),(
            math.max(row.getLong(1)/timesample_ms*timesample_ms,starttime) to (
              if (row.get(4).anyToLongOpt.getOrElse(0L)>0)
                math.min(row.get(4).anyToLongOpt.getOrElse(0L)/timesample_ms*timesample_ms,endtime)
              else
                endtime
            ) by timesample_ms
          ).toArray
        )
      );

    val locts_df = locts.flatMapValues(x=>x).
      map(
        {
          case (LocEvent(imsi,loctimestamp,key,rattype,nxttime,nxtkey,prevtime,prevkey),ts) => 
            LocExpandedTS(imsi,loctimestamp,key,rattype,nxttime,nxtkey,prevtime,prevkey,ts.toLong)
        }
      );
    
    val locts_keyed = locts_df.keyBy(LocExpandedTS=>Array(LocExpandedTS.imsi,LocExpandedTS.sampletime.toString).mkString(","))
    val locts_reduced = locts_keyed.
      combineByKey(
        (x: LocExpandedTS)=>x,
        ((x: LocExpandedTS),(acc:LocExpandedTS))=>{if (x.loctimestamp <= acc.loctimestamp) x else acc},
        ((acc1: LocExpandedTS),(acc2:LocExpandedTS))=>(if (acc1.loctimestamp <= acc2.loctimestamp) acc1 else acc2)
      )
    
    val locts_output = locts_reduced.
      map(
        {
          case (k,LocExpandedTS(imsi,loctimestamp,key,rattype,nxttime,nxtkey,prevtime,prevkey,sampletime))=>
            LocExpandedTS(imsi,loctimestamp,key,rattype,nxttime,nxtkey,prevtime,prevkey,sampletime)
        }
      ).toDF()
    
    locts_output.write.parquet(locexpandedts_path)
    
     sc.stop
   }
}
